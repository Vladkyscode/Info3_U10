from django.views import generic
from .models import OurModel

class YourModelListView(generic.ListView):
    model = OurModel
    template_name = 'your_model_list.html'
    context_object_name = 'your_model_list'